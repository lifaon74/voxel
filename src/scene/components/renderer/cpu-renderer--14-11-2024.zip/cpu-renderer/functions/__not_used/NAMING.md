

line: composed of an origin point and a vector. goes infinitely in both direction.
semi-line: composed of an origin point and a vector. goes infinitely in only one direction.
ray: composed of an origin point and a vector. goes in only one direction, and stops at vector's end.

plan: a 2d infinite surface
surface: a 2d finite surface
