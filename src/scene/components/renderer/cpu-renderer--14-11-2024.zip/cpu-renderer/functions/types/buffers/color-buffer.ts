export type ColorBuffer = Uint8Array | Uint8ClampedArray; // u8[(r <u8>, g <u8>, b <u8>, a <u8>) * width * height]
