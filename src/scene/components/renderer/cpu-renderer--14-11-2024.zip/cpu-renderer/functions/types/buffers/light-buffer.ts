export type LightBuffer = Float32Array; // f32[(r <f32>, g <f32>, b <f32>) * width * height]
