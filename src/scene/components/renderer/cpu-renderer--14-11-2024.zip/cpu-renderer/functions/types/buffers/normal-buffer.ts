export type NormalBuffer = Float32Array; // f32[(x <f32>, y <f32>, z <f32>) * width * height]
