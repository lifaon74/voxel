import { u32 } from '@lifaon/math';
import { AbstractTexture2D } from '../abstract-texture-2d';
import { CreateTexture2D } from './create-texture-2d';

export class AbstractTexture2DFactory<GTexture2D extends AbstractTexture2D> {
  readonly create: CreateTexture2D<GTexture2D>;

  constructor(create: CreateTexture2D<GTexture2D>) {
    this.create = create;
  }

  async fromUrl(url: URL | string): Promise<GTexture2D> {
    return this.fromImageBitmapSource(await (await fetch(url)).blob(), undefined);
  }

  async fromImageBitmapSource(
    image: ImageBitmapSource,
    options: ImageBitmapOptions | undefined,
  ): Promise<GTexture2D> {
    return this.fromImageBitmap(await createImageBitmap(image, options));
  }

  fromImageBitmap(imageBitmap: ImageBitmap): GTexture2D {
    const ctx: OffscreenCanvasRenderingContext2D = new OffscreenCanvas(
      imageBitmap.width,
      imageBitmap.height,
    ).getContext('2d')!;
    ctx.drawImage(imageBitmap, 0, 0);
    return this.fromImageData(ctx.getImageData(0, 0, imageBitmap.width, imageBitmap.height));
  }

  fromImageData(imageData: ImageData): GTexture2D {
    const texture: GTexture2D = this.create(imageData.width, imageData.height);
    let i: u32 = 0;
    for (let y: u32 = 0; y < imageData.height; y++) {
      for (let x: u32 = 0; x < imageData.width; x++) {
        texture.setColor(
          x,
          y,
          imageData.data[i],
          imageData.data[i + 1],
          imageData.data[i + 2],
          imageData.data[i + 3],
        );
        i += 4;
      }
    }
    return texture;
  }
}
