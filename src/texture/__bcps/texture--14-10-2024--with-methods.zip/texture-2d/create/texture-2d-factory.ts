import { u32 } from '@lifaon/math';
import { Texture2D } from '../texture-2d';
import { AbstractTexture2DFactory } from './abstract-texture-2d-factory';

export class Texture2DFactory extends AbstractTexture2DFactory<Texture2D> {
  constructor() {
    super((x: u32, y: u32): Texture2D => {
      return new Texture2D(x, y);
    });
  }

  override fromImageData(imageData: ImageData): Texture2D {
    return new Texture2D(imageData.width, imageData.height, imageData.data);
  }
}
