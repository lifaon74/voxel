import { u32 } from '@lifaon/math';
import { AbstractTexture2D } from '../abstract-texture-2d';

export interface CreateTexture2D<GTexture2D extends AbstractTexture2D = AbstractTexture2D> {
  (x: u32, y: u32): GTexture2D;
}
