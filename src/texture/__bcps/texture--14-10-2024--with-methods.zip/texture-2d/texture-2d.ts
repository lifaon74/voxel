import { u32, u8 } from '@lifaon/math';
import { TextureColor } from '../texture-color';
import { AbstractTexture2D } from './abstract-texture-2d';
import { Texture2DFactory } from './create/texture-2d-factory';

export class Texture2D extends AbstractTexture2D {
  // static readonly factory: Texture2DFactory = new Texture2DFactory();

  readonly data: Uint8ClampedArray;

  constructor(x: u32, y: u32, data?: Uint8ClampedArray) {
    const bytesLength: u32 = x * y * 4;
    if (data === undefined) {
      data = new Uint8ClampedArray(bytesLength);
    } else if (data.length !== bytesLength) {
      throw new Error("Data size doesn't match x, y size.");
    }
    super(x, y);
    this.data = data;
  }

  override setColor(
    // position
    x: u32,
    y: u32,
    // color
    r: u8,
    g: u8,
    b: u8,
    a: u8,
  ): void {
    const index: u32 = this.getIndexFromPosition(x, y);
    this.data[index] = r;
    this.data[index + 1] = g;
    this.data[index + 2] = b;
    this.data[index + 3] = a;
  }

  override getColor(x: u32, y: u32): TextureColor {
    const index: u32 = this.getIndexFromPosition(x, y);
    return [this.data[index], this.data[index + 1], this.data[index + 2], this.data[index + 3]];
  }

  getIndexFromPosition(x: u32, y: u32): u32 {
    return (x + y * this.x) * 4;
  }

  override toImageData(): ImageData {
    return new ImageData(this.data, this.x, this.y);
  }
}
