import { draw_image_data } from '../../../image/canvas/draw_image_data';
import { AbstractTexture2D } from '../abstract-texture-2d';

export function draw_texture_3d(texture3d: AbstractTexture2D, scale?: number): void {
  draw_image_data(texture3d.sliceIntoImageData(), scale);
}
