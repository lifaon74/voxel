import { u8 } from '@lifaon/math';

export type TextureColor = readonly [r: u8, g: u8, b: u8, a: u8];
