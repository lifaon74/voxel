import { u32, u8 } from '@lifaon/math';
import { TextureColor } from '../texture-color';
import { AbstractTexture3D } from './abstract-texture-3d';
import { CreateTexture3D } from './create/create-texture-3d';
import { Texture3DFactory } from './create/texture-3d-factory';

export class Texture3D extends AbstractTexture3D {
  static readonly factory: Texture3DFactory = new Texture3DFactory();

  static create: CreateTexture3D<Texture3D> = (x: u32, y: u32, z: u32): Texture3D => {
    return new Texture3D(x, y, z);
  };

  readonly data: Uint8ClampedArray;

  constructor(x: u32, y: u32, z: u32, data?: Uint8ClampedArray) {
    const bytesLength: u32 = x * y * z * 4;
    if (data === undefined) {
      data = new Uint8ClampedArray(bytesLength);
    } else if (data.length !== bytesLength) {
      throw new Error("Data size doesn't match x, y, z size");
    }
    super(x, y, z);
    this.data = data;
  }

  override setColor(
    // position
    x: u32,
    y: u32,
    z: u32,
    // color
    r: u8,
    g: u8,
    b: u8,
    a: u8,
  ): void {
    const index: u32 = this.getIndexFromPosition(x, y, z);
    this.data[index] = r;
    this.data[index + 1] = g;
    this.data[index + 2] = b;
    this.data[index + 3] = a;
  }

  override getColor(x: u32, y: u32, z: u32): TextureColor {
    const index: u32 = this.getIndexFromPosition(x, y, z);
    return [this.data[index], this.data[index + 1], this.data[index + 2], this.data[index + 3]];
  }

  getIndexFromPosition(x: u32, y: u32, z: u32): u32 {
    return (x + y * this.x + z * this.x * this.y) * 4;
  }

  override toImageData(): ImageData {
    return new ImageData(this.data, this.x, this.y * this.z);
  }
}
