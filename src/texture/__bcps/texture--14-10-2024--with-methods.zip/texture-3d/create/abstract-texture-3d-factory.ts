import { AbstractTexture3D } from '../abstract-texture-3d';
import { CreateTexture3D } from './create-texture-3d';

export class AbstractTexture3DFactory<GTexture3D extends AbstractTexture3D> {
  readonly create: CreateTexture3D<GTexture3D>;

  constructor(create: CreateTexture3D<GTexture3D>) {
    this.create = create;
  }
}
