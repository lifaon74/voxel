import { u32 } from '@lifaon/math';
import { Texture3D } from '../texture-3d';
import { AbstractTexture3DFactory } from './abstract-texture-3d-factory';

export class Texture3DFactory extends AbstractTexture3DFactory<Texture3D> {
  constructor() {
    super((x: u32, y: u32, z: u32): Texture3D => {
      return new Texture3D(x, y, z);
    });
  }
}
