import { u32 } from '@lifaon/math';
import { AbstractTexture3D } from '../abstract-texture-3d';

export interface CreateTexture3D<GTexture3D extends AbstractTexture3D = AbstractTexture3D> {
  (x: u32, y: u32, z: u32): GTexture3D;
}
