import { u32, u8 } from '@lifaon/math';
import { TextureColor } from '../texture-color';

export abstract class AbstractTexture3D {
  readonly x: u32;
  readonly y: u32;
  readonly z: u32;

  constructor(x: u32, y: u32, z: u32) {
    this.x = x;
    this.y = y;
    this.z = z;
  }

  abstract setColor(
    // position
    x: u32,
    y: u32,
    z: u32,
    // color
    r: u8,
    g: u8,
    b: u8,
    a: u8,
  ): void;

  abstract getColor(x: u32, y: u32, z: u32): TextureColor;

  /**
   * Slices the texture 3d, and put them inside an ImageData.
   */
  toImageData(): ImageData {
    const output: ImageData = new ImageData(this.x, this.y * this.z);
    let i: u32 = 0;
    for (let z: u32 = 0; z < this.z; z++) {
      for (let y: u32 = 0; y < this.y; y++) {
        for (let x: u32 = 0; x < this.x; x++) {
          output.data.set(this.getColor(x, y, z), i);
          i += 4;
        }
      }
    }
    return output;
  }
}
