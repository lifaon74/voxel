import { U32_BYTE_SIZE } from '../memory/operations/u32-byte-size.constant';

export const VOXEL_OCTREE_BYTE_SIZE = 1 + U32_BYTE_SIZE * 8;
