export const U32_BYTE_SIZE = 4;
