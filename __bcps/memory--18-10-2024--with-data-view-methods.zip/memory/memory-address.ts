import { usize } from '@lifaon/math';

export type MemoryAddress = usize;
