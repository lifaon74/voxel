import { f32, u32 } from '@lifaon/math';
import { MemoryAddress } from '../../memory-address';

export interface MemorySetUint32Trait {
  setUint32(address: MemoryAddress, value: u32, littleEndian?: boolean): void;
}
