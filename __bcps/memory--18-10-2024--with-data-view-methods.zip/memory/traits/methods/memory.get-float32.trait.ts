import { f32 } from '@lifaon/math';
import { MemoryAddress } from '../../memory-address';

export interface MemoryGetFloat32Trait {
  getFloat32(address: MemoryAddress, littleEndian?: boolean): f32;
}
