import { u8 } from '@lifaon/math';
import { MemoryAddress } from '../../memory-address';

export interface MemorySetUint8Trait {
  setUint8(address: MemoryAddress, value: u8): void;
}
