import { f32 } from '@lifaon/math';
import { MemoryAddress } from '../../memory-address';

export interface MemorySetFloat32Trait {
  setFloat32(address: MemoryAddress, value: f32, littleEndian?: boolean): void;
}
