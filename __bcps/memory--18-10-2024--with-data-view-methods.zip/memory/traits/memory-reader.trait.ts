import { MemoryReaderNextTrait } from './methods/memory-reader.next.trait';
import { ReadonlyMemoryTrait } from './readonly-memory.trait';

export interface MemoryReaderTrait extends ReadonlyMemoryTrait, MemoryReaderNextTrait {}
