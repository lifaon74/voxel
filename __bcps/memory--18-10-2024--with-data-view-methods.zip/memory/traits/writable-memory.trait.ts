import { MemorySetFloat32Trait } from './methods/memory.set-float32.trait';
import { MemorySetUint32Trait } from './methods/memory.set-uint32.trait';
import { MemorySetUint8Trait } from './methods/memory.set-uint8.trait';
import { ReadonlyMemoryTrait } from './readonly-memory.trait';

export interface WritableMemoryTrait
  extends ReadonlyMemoryTrait,
    MemorySetFloat32Trait,
    MemorySetUint8Trait,
    MemorySetUint32Trait {}
