import { debugRayTrace } from './__debug/debug-raytrace';
import { debugVoxel } from './__debug/debug-voxel';

function main(): void {
  debugVoxel();
  // debugRayTrace();
}

window.onload = main;

