import { math_floor, u32, u8 } from '@lifaon/math';
import { allocate_and_write_voxel_material_in_memory } from '../../material/functions/allocate/allocate_and_write_voxel_material_in_memory';
import { IMemory } from '../../memory/memory.type';
import { IMemoryAddress } from '../../memory/types/memory-address.type';
import { IMemoryAllocFunction } from '../../memory/types/memory-alloc-function.type';
import { voxel_octree_depth_to_side } from '../../octree/functions/depth-side/voxel_octree_depth_to_side';
import {
  allocate_and_write_voxel_material_address_in_memory_of_voxel_octree_at_position,
} from '../../octree/functions/voxel-material/at-position/allocate_and_write_voxel_material_address_in_memory_of_voxel_octree_at_position';

export function generateRainbowVoxelOctree(
  memory: IMemory,
  alloc: IMemoryAllocFunction,
  voxelOctreeAddress: IMemoryAddress,
  voxelOctreeDepth: u8,
): void {
  const side: u32 = voxel_octree_depth_to_side(voxelOctreeDepth);
  const f: number = 255 / side;

  for (let z: u32 = 0; z < side; z++) {
    for (let y: u32 = 0; y < side; y++) {
      for (let x: u32 = 0; x < side; x++) {
        const voxelMaterialAddress: IMemoryAddress = allocate_and_write_voxel_material_in_memory(
          memory,
          alloc,
          math_floor(x * f),
          math_floor(y * f),
          math_floor(z * f),
        );

        allocate_and_write_voxel_material_address_in_memory_of_voxel_octree_at_position(
          memory,
          alloc,
          voxelOctreeAddress,
          voxelOctreeDepth,
          x,
          y,
          z,
          voxelMaterialAddress,
        );
      }
    }
  }
}
