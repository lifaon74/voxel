import { is_valid_point, make_point_invalid, u16_vec3, u16_vec3_create, u32, u8, vec3, vec3_create } from '@lifaon/math';
import { IMemory } from '../memory/memory.type';
import { IMemoryAddress } from '../memory/types/memory-address.type';
import { voxel_octree_depth_to_side } from '../octree/functions/depth-side/voxel_octree_depth_to_side';
import {
  get_voxel_octree_child_index_from_position_3d
} from '../octree/functions/voxel-octree-child/index/get_voxel_octree_child_index_from_position_3d';
import { NO_MATERIAL } from '../octree/special-addresses.constant';


/**
 * A normalized cube:
 * - has the position [0, 0, 0]
 * - has the size [1, 1, 1] (side = 1)
 *
 * A normalized line-segment (0, 0)->(0, 1):
 *
 * A normalized voxel-octree:
 * - has the position [0, 0, 0]
 */


const VOXEL_OCTREE_COORDINATES: u16_vec3 = u16_vec3_create();
const VOXEL_OCTREE_CHILD_POSITION: vec3 = vec3_create();

export function get_intersection_point_3d_of_ray_3d_with_voxel_octree(
  out: vec3,
  // RAY
  ray_position: vec3,
  ray_vector: vec3,
  // VOXEL_OCTREE
  memory: IMemory,
  voxelOctreeAddress: IMemoryAddress,
  voxelOctreeDepth: u8,
): IMemoryAddress { // voxelMaterialAddress
  make_point_invalid(out);

  const side: u32 = voxel_octree_depth_to_side(voxelOctreeDepth);
  get_intersection_entry_point_3d_of_ray_3d_with_cube(out, ray_position, ray_vector, side);

  let i: number = 0;
  if (is_valid_point(out)) {
    while (i++ < side) {
      convert_intersection_point_to_voxel_octree_coordinates(VOXEL_OCTREE_COORDINATES, out, ray_vector);

      let localVoxelOctreeAddress: IMemoryAddress = voxelOctreeAddress;
      let localVoxelOctreeDepth: number = voxelOctreeDepth;

      while (localVoxelOctreeDepth >= 0) {
        const voxelOctreeChildIndex: number = get_voxel_octree_child_index_from_position_3d(
          localVoxelOctreeDepth,
          VOXEL_OCTREE_COORDINATES[0],
          VOXEL_OCTREE_COORDINATES[1],
          VOXEL_OCTREE_COORDINATES[2],
        );
        const voxelOctreeChildAddress: number = readAddress(memory, convertVoxelOctreeChildIndexToVoxelOctreeChildAddressAddressUsingIndex(localVoxelOctreeAddress, voxelOctreeChildIndex));
        if (isVoxelOctreeChildIndexAVoxelOctreeAddress(memory, localVoxelOctreeAddress, voxelOctreeChildIndex)) {
          localVoxelOctreeAddress = voxelOctreeChildAddress;
          localVoxelOctreeDepth--;
        } else {
          if (voxelOctreeChildAddress === NO_MATERIAL) {
            const localSide: number = 1 << localVoxelOctreeDepth;
            convertVoxelOctreeCoordinatesToVoxelOctreeChildPosition(VOXEL_OCTREE_COORDINATES, localSide, VOXEL_OCTREE_CHILD_POSITION);
            hitCubeOut(rayPosition, ray_vector, VOXEL_OCTREE_CHILD_POSITION, localSide, out);

            if (!is_valid_point(out)) {
              debugger;
              hitCubeOut(rayPosition, ray_vector, VOXEL_OCTREE_CHILD_POSITION, localSide, out);
              return NO_MATERIAL;
            }

            if (isPointOnCubeSurfaceOrOut(out, side)) {
              return NO_MATERIAL;
            } else {
              break;
            }
          } else {
            return voxelOctreeChildAddress;
          }
        }
      }
    }
  }

  return NO_MATERIAL;
}


export function convert_intersection_point_to_voxel_octree_coordinates(
  // the voxel_octree_coordinates point
  out: u16_vec3,
  point: vec3,
  ray_vector: vec3,
): void {
  out[5] = 8;
  // intHitPosition[0] = hitPosition[0] - ((ray_vector[0] < 0) ? Number.EPSILON : 0);
  // intHitPosition[1] = hitPosition[1] - ((ray_vector[1] < 0) ? Number.EPSILON : 0);
  // intHitPosition[2] = hitPosition[2] - ((ray_vector[2] < 0) ? Number.EPSILON : 0);
  for (let i: number = 0; i < 3; i++) {
    out[i] = point[i];
    if (
      (ray_vector[i] < 0)
      && (out[i] === point[i])
    ) {
      out[i]--;
    }
  }
}

/**
 * Returns the entry point of a ray with a cube.
 */
export function get_intersection_entry_point_3d_of_ray_3d_with_cube(
  // the intersection point
  out: vec3,
  // RAY
  ray_position: vec3,
  ray_vector: vec3,
  // CUBE SIZE
  side: u32,
): vec3 {
  let a: number, b: number, c: number;

  for (a = 0; a < 3; a++) { // for each surface (by axis) of the cube
    b = (a + 1) % 3;
    c = (a + 2) % 3;

    if (ray_vector[a] !== 0) { // if the ray is not parallel to this surface
      if (ray_vector[a] > 0) {
        if (ray_position[a] >= side) { // point after exit surface
          break;
        } else {
          out[a] = (ray_position[a] > 0)
            ? ray_position[a] // in the cube
            : 0;
        }
      } else { // if (ray_vector[a] < 0)
        if (ray_position[a] <= 0) { // point after exit surface
          break;
        } else {
          out[a] = (ray_position[a] < side)
            ? ray_position[a] // in the cube
            : side;
        }
      }

      out[b] = ray_position[b] + (
        (out[a] - ray_position[a]) * (ray_vector[b] / ray_vector[a])
      ); // thales

      if (
        (
          (out[b] > 0)
          || ((out[b] === 0) && (ray_vector[b] >= 0))
        )
        && (
          (out[b] < side)
          || ((out[b] === side) && (ray_vector[b] < 0))
        ) // out[b] inside or next step inside
      ) {

        out[c] = ray_position[c] + (
          (out[a] - ray_position[a]) * (ray_vector[c] / ray_vector[a])
        );  // thales

        if (
          ((out[c] > 0) || ((out[c] === 0) && (ray_vector[c] >= 0))) // out[c] inside or next step inside
          && ((out[c] < side) || ((out[c] === side) && (ray_vector[c] < 0)))
        ) {
          return out;
        }
      }
    }
  }

  make_point_invalid(out)
  return out;
}

export function get_intersection_exit_point_3d_of_ray_3d_with_cube(
  // the intersection point
  out: vec3,
  // RAY
  ray_position: vec3,
  ray_vector: vec3,
  // CUBE SIZE
  side: u32,
): vec3 {
  let a: number, b: number, c: number;

  for (a = 0; a < 3; a++) {
    b = (a + 1) % 3;
    c = (a + 2) % 3;

    if (ray_vector[a] !== 0) {
      if (ray_vector[a] > 0) {
        if (ray_position[a] > (cubePosition[a] + side)) { // point after exit surface
          break;
        } else {
          out[a] = cubePosition[a] + side;
        }
      } else { // if (ray_vector[a] < 0)
        if (ray_position[a] < cubePosition[a]) { // point after exit surface
          break;
        } else {
          out[a] = cubePosition[a];
        }
      }

      out[b] = ray_position[b] + (
        (out[a] - ray_position[a]) * (ray_vector[b] / ray_vector[a])
      ); // thales

      if ((cubePosition[b] <= out[b]) && (out[b] <= (side + cubePosition[b]))) {

        out[c] = ray_position[c] + (
          (out[a] - ray_position[a]) * (ray_vector[c] / ray_vector[a])
        );  // thales

        if (
          (cubePosition[c] <= out[c]) && (out[c] <= (side + cubePosition[c]))
        ) {
          return out;
        }
      }
    }
  }

  make_point_invalid(out)
  return out;
}


function debugRayTrace1() {

}

/*--------------------------*/

export async function debugRayTrace() {
  debugRayTrace1();
}
