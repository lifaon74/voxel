import { u8 } from '@lifaon/math';
import { IMemory } from '../../memory/memory.type';
import { IMemoryAddress } from '../../memory/types/memory-address.type';

export interface ISliceVoxelOctreeCallback {
  (
    memory: IMemory,
    voxelOctreeAddress: IMemoryAddress,
    voxelOctreeDepth: u8,
    x: number,
    y: number,
  ): IMemoryAddress;
}
