export const NO_MATERIAL = 0xffffffff;
export const NON_UNIFORM_MATERIAL = 0xfffffffd;
export const UNDEFINED_MATERIAL = 0xfffffffc;
