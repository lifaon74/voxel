import { SIZEOF_U8 } from '../../memory/functions/read-write/u8/sizeof_u8.constant';

export const SIZEOF_VOXEL_MATERIAL = SIZEOF_U8 * 3;
