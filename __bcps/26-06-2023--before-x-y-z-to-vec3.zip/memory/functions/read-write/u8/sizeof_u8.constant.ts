export const SIZEOF_U8 = 1;
