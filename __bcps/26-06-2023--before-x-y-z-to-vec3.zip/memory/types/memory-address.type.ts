import { u32 } from '@lifaon/math';

export type IMemoryAddress = u32;
