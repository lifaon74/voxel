export type IMemory = DataView;

