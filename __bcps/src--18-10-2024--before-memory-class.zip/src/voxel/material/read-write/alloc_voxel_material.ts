import { AllocFunction, usize } from '@lifaon/math';
import { SIZEOF_VOXEL_MATERIAL } from './sizeof_voxel_material.constant';

export function alloc_voxel_material(alloc: AllocFunction): u32 {
  return alloc(SIZEOF_VOXEL_MATERIAL);
}
