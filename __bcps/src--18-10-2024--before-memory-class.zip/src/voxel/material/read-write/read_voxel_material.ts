import { BytesBuffer, u32 } from '@lifaon/math';
import { VoxelMaterial } from './voxel-material';

export function read_voxel_material(buffer: BytesBuffer, voxelMaterialAddress: u32): VoxelMaterial {
  return buffer.subarray(voxelMaterialAddress, 3) as unknown as VoxelMaterial;
}
