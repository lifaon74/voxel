import { BytesBuffer, u32, u8 } from '@lifaon/math';

export function write_voxel_material(
  buffer: BytesBuffer,
  voxelMaterialAddress: u32,
  r: u8,
  g: u8,
  b: u8,
): void {
  buffer[voxelMaterialAddress] = r;
  buffer[voxelMaterialAddress + 1] = g;
  buffer[voxelMaterialAddress + 2] = b;
}
