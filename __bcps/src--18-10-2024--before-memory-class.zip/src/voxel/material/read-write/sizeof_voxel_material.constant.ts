import { SIZEOF_U8 } from '@lifaon/math';

export const SIZEOF_VOXEL_MATERIAL = SIZEOF_U8 * 3; // [red (u8), green (u8), blue (u8)]
