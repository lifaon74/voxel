import { u8 } from '@lifaon/math';

export type VoxelMaterial = readonly [r: u8, g: u8, b: u8];
