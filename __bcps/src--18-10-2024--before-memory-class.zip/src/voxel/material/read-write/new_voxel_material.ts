import { AllocFunction, BytesBuffer, u8, usize } from '@lifaon/math';
import { alloc_voxel_material } from './alloc_voxel_material';
import { write_voxel_material } from './write_voxel_material';

export function new_voxel_material(
  buffer: BytesBuffer,
  alloc: AllocFunction,
  r: u8,
  g: u8,
  b: u8,
): u32 {
  const voxelMaterialAddress: u32 = alloc_voxel_material(alloc);
  write_voxel_material(buffer, voxelMaterialAddress, r, g, b);
  return voxelMaterialAddress;
}
