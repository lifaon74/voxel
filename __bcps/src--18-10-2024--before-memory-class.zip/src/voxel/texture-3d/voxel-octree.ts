import { AllocFunction, BytesBuffer, u32, u8, vec3_u32 } from '@lifaon/math';
import { NEW } from '@lifaon/traits';
import { Texture3DCropTrait } from '../../texture/texture-3d/traits/methods/texture-3d.crop.trait';
import { Texture3DGetColorTrait } from '../../texture/texture-3d/traits/methods/texture-3d.get-color.trait';
import { Texture3DSetColorTrait } from '../../texture/texture-3d/traits/methods/texture-3d.set-color.trait';
import { Texture3DToImageDataTrait } from '../../texture/texture-3d/traits/methods/texture-3d.to-image-data.trait';
import { Texture3DSizeTrait } from '../../texture/texture-3d/traits/properties/texture-3d.size.trait';
import { Texture3DNewTrait } from '../../texture/texture-3d/traits/well-known/texture-3d.new.trait';
import { TextureColor } from '../../texture/texture-color';
import { read_voxel_material } from '../material/read-write/read_voxel_material';
import { voxel_octree_depth_to_side } from '../octree/depth-side/voxel_octree_depth_to_side';
import { read_voxel_material_address_inside_voxel_octree_at_position } from '../octree/read-write/voxel-material/at-position/read_voxel_material_address_inside_voxel_octree_at_position';
import { NO_MATERIAL } from '../octree/special-addresses.constant';

export interface ReadonlyVoxelOctreeOptions {
  readonly buffer: BytesBuffer;
  readonly address: u32;
  readonly depth: u8;
}

export class ReadonlyVoxelOctree implements Texture3DSizeTrait, Texture3DGetColorTrait {
  readonly x: u32;
  readonly y: u32;
  readonly z: u32;

  readonly buffer: BytesBuffer;
  readonly address: u32;
  readonly depth: u8;

  constructor({ buffer, address, depth }: ReadonlyVoxelOctreeOptions) {
    const side: u32 = voxel_octree_depth_to_side(depth);
    this.x = side;
    this.y = side;
    this.z = side;
    this.buffer = buffer;
    this.address = address;
    this.depth = depth;
  }

  getColor(x: u32, y: u32, z: u32): TextureColor {
    const voxelMaterialAddress: u32 = read_voxel_material_address_inside_voxel_octree_at_position(
      this.buffer,
      this.address,
      this.depth,
      [x, y, z] as unknown as vec3_u32,
    );
    if (voxelMaterialAddress === NO_MATERIAL) {
      return [0, 0, 0, 0];
    } else {
      return [...read_voxel_material(this.buffer, voxelMaterialAddress), 0];
    }
  }
}

/*---*/

// export interface VoxelOctreeOptions extends ReadonlyVoxelOctreeOptions {
//   readonly alloc: AllocFunction;
// }
//
// export class VoxelOctree extends ReadonlyVoxelOctree implements Texture3DSetColorTrait {
//   static create(x: u32, y: u32, z: u32): VoxelOctree {
//     throw 'TODO';
//     // return new VoxelOctree(x, y, z);
//   }
//
//   constructor(x: u32, y: u32, z: u32, data?: Uint8ClampedArray) {
//     const bytesLength: u32 = x * y * z * 4;
//     if (data === undefined) {
//       data = new Uint8ClampedArray(bytesLength);
//     } else if (data.length !== bytesLength) {
//       throw new Error("Data size doesn't match x, y, z size.");
//     }
//     this.x = x;
//     this.y = y;
//     this.z = z;
//     this.data = data;
//   }
//
//   setColor(
//     // position
//     x: u32,
//     y: u32,
//     z: u32,
//     // color
//     r: u8,
//     g: u8,
//     b: u8,
//     a: u8,
//   ): void {
//     const index: u32 = this.getIndexFromPosition(x, y, z);
//     this.data[index] = r;
//     this.data[index + 1] = g;
//     this.data[index + 2] = b;
//     this.data[index + 3] = a;
//   }
// }
