import { BytesBuffer, read_u8, u32, u8, write_u8 } from '@lifaon/math';

/**
 * Update the mask of the `voxelOctreeChild` to be considered as a `voxelOctree`.
 */
export function set_voxel_octree_child_as_voxel_octree_using_index(
  buffer: BytesBuffer,
  voxelOctreeAddress: u32,
  voxelOctreeChildIndex: u8,
): void {
  write_u8(
    buffer,
    voxelOctreeAddress,
    read_u8(buffer, voxelOctreeAddress) | (0x1 << voxelOctreeChildIndex),
  );
}
