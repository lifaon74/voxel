import { BytesBuffer, read_u8, u8 } from '@lifaon/math';

/**
 * Returns true if the `voxelOctreeChild` located at `voxelOctreeChildIndex`, is a `voxelOctreeAddress`, else it's a `voxelMaterialAddress`.
 */
export function is_voxel_octree_child_index_a_voxel_octree_address(
  buffer: BytesBuffer,
  voxelOctreeAddress: u32,
  voxelOctreeChildIndex: u8,
): boolean {
  return ((read_u8(buffer, voxelOctreeAddress) >> voxelOctreeChildIndex) &
    0x1) as unknown as boolean;
}
