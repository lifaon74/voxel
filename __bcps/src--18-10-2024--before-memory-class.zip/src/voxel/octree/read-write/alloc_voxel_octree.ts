import { AllocFunction } from '@lifaon/math';
import { SIZEOF_VOXEL_OCTREE } from './sizeof_voxel_octree.constant';

export function alloc_voxel_octree(alloc: AllocFunction): u32 {
  return alloc(SIZEOF_VOXEL_OCTREE);
}
