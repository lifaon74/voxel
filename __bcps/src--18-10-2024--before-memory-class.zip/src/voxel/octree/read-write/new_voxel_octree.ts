import { AllocFunction, BytesBuffer, u32 } from '@lifaon/math';
import { alloc_voxel_octree } from './alloc_voxel_octree';
import { write_voxel_octree } from './write_voxel_octree';

export function new_voxel_octree(
  buffer: BytesBuffer,
  alloc: AllocFunction,
  voxelMaterialAddress: u32,
): u32 {
  const voxelOctreeAddress: u32 = alloc_voxel_octree(alloc);
  write_voxel_octree(buffer, voxelOctreeAddress, voxelMaterialAddress);
  return voxelOctreeAddress;
}
