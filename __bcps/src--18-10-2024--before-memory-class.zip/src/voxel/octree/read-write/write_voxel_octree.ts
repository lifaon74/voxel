import { BytesBuffer, SIZEOF_U32, u32, write_u32_be, write_u8 } from '@lifaon/math';

export function write_voxel_octree(
  buffer: BytesBuffer,
  voxelOctreeAddress: u32,
  voxelMaterialAddress: u32,
): void {
  write_u8(buffer, voxelOctreeAddress, 0b00000000);
  voxelOctreeAddress++;

  for (let i: number = 0; i < 8; i++) {
    write_u32_be(buffer, voxelOctreeAddress, voxelMaterialAddress);
    voxelOctreeAddress += SIZEOF_U32;
  }
}
