import { AllocFunction, BytesBuffer, read_u32_be, u32, u8, write_u32_be } from '@lifaon/math';
import { VoxelOctreePosition3D } from '../../../types/voxel-octree-position-3d';
import { get_voxel_octree_child_index_from_position_3d } from '../../../voxel-octree-child/index/get_voxel_octree_child_index_from_position_3d';
import { get_voxel_octree_child_memory_address_from_voxel_octree_child_index } from '../../../voxel-octree-child/index/get_voxel_octree_child_memory_address_from_voxel_octree_child_index';
import { is_voxel_octree_child_index_a_voxel_octree_address } from '../../../voxel-octree-child/index/is_voxel_octree_child_index_a_voxel_octree_address';
import { set_voxel_octree_child_as_voxel_octree_using_index } from '../../../voxel-octree-child/type/set_voxel_octree_child_as_voxel_octree_using_index';
import { new_voxel_octree } from '../../new_voxel_octree';

export function insert_voxel_material_address_inside_voxel_octree_at_position(
  buffer: BytesBuffer,
  alloc: AllocFunction,
  voxelOctreeAddress: u32,
  voxelOctreeDepth: u8,
  position: VoxelOctreePosition3D,
  voxelMaterialAddress: u32,
): void {
  // insert <voxelMaterialAddress> at proper place
  while (voxelOctreeDepth >= 0) {
    const voxelOctreeChildIndex: u8 = get_voxel_octree_child_index_from_position_3d(
      voxelOctreeDepth,
      position,
    );

    const voxelOctreeChildAddressAddress: u32 =
      get_voxel_octree_child_memory_address_from_voxel_octree_child_index(
        voxelOctreeAddress,
        voxelOctreeChildIndex,
      );

    if (voxelOctreeDepth === 0) {
      // for depth === 0 mask should be equals to <voxelMaterialAddress> by default
      write_u32_be(buffer, voxelOctreeChildAddressAddress, voxelMaterialAddress);
      break;
    } else {
      const voxelOctreeChildAddress: u32 = read_u32_be(buffer, voxelOctreeChildAddressAddress);

      if (
        is_voxel_octree_child_index_a_voxel_octree_address(
          buffer,
          voxelOctreeAddress,
          voxelOctreeChildIndex,
        )
      ) {
        // is <voxelOctreeAddress>
        voxelOctreeAddress = voxelOctreeChildAddress;
      } else {
        // is <voxelMaterialAddress>
        if (voxelOctreeChildAddress === voxelMaterialAddress) {
          // same values
          break; // here we are not at the deepest lvl, <voxelMaterialAddress>es are the same and the <voxelOctree> should already be optimized => touch nothing
        } else {
          // <voxelMaterialAddress>es are different => must split current <voxelMaterialAddress> into another <voxelOctree>
          // allocate memory for a new <voxelOctree>, and initializes the new <voxelOctree> with <voxelMaterialAddress>
          const newVoxelOctreeAddress: u32 = new_voxel_octree(
            buffer,
            alloc,
            voxelOctreeChildAddress,
          );

          // update mask to <voxelOctreeAddress> type
          set_voxel_octree_child_as_voxel_octree_using_index(
            buffer,
            voxelOctreeAddress,
            voxelOctreeChildIndex,
          );

          // replace the old <voxelMaterialAddress> with the new <voxelOctreeAddress>
          write_u32_be(buffer, voxelOctreeChildAddressAddress, newVoxelOctreeAddress);

          voxelOctreeAddress = newVoxelOctreeAddress;
        }
      }
    }

    voxelOctreeDepth--;
  }
}
