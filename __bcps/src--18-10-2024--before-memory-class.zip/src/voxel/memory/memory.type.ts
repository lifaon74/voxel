/**
 * @deprecated use BytesBuffer
 */
export type IMemory = Uint8Array;
