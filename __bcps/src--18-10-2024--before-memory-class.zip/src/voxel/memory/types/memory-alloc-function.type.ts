import { u32 } from '@lifaon/math';
import { IMemoryAddress } from './memory-address.type';

/**
 * @deprecated use AllocFunction
 */
export interface IMemoryAllocFunction {
  (
    size: u32, // the size to alloc
  ): IMemoryAddress; // the address of the allocated memory portion
}
