import { u32 } from '@lifaon/math';

/**
 * @deprecated use usize
 */
export type IMemoryAddress = u32;
