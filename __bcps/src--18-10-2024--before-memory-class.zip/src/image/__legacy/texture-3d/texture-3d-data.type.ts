export type ITexture3DData = [size: { x: number; y: number; z: number }, voxels: Uint8Array];
