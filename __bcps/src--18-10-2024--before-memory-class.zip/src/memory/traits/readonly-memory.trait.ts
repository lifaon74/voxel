import { MemoryGetFloat32Trait } from './methods/memory.get-float32.trait';
import { MemoryGetUint32Trait } from './methods/memory.get-uint32.trait';
import { MemoryGetUint8Trait } from './methods/memory.get-uint8.trait';
import { MemoryBufferTrait } from './properties/memory.buffer.trait';

export interface ReadonlyMemoryTrait
  extends MemoryBufferTrait,
    MemoryGetFloat32Trait,
    MemoryGetUint8Trait,
    MemoryGetUint32Trait {}
