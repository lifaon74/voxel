import { MemoryAllocTrait } from './methods/memory.alloc.trait';
import { MemoryFreeTrait } from './methods/memory.free.trait';
import { WritableMemoryTrait } from './writable-memory.trait';

export interface MemoryTrait extends WritableMemoryTrait, MemoryAllocTrait, MemoryFreeTrait {}
