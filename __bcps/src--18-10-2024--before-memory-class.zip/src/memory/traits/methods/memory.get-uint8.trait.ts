import { u8 } from '@lifaon/math';
import { MemoryAddress } from '../../memory-address';

export interface MemoryGetUint8Trait {
  getUint8(address: MemoryAddress): u8;
}
