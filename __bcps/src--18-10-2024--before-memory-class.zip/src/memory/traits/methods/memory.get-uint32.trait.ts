import { f32, u32 } from '@lifaon/math';
import { MemoryAddress } from '../../memory-address';

export interface MemoryGetUint32Trait {
  getUint32(address: MemoryAddress, littleEndian?: boolean): u32;
}
