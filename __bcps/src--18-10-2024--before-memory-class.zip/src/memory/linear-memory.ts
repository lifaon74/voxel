import { usize } from '@lifaon/math';
import { MemoryAddress } from './memory-address';
import { MemoryTrait } from './traits/memory.trait';

export class LinearMemory extends DataView implements MemoryTrait {
  #cursor: number = 0;

  alloc(size: usize): MemoryAddress {
    if (size === 0) {
      return this.#cursor;
    } else {
      const index: number = this.#cursor;
      this.#cursor += size;
      if (this.#cursor > this.buffer.byteLength) {
        throw new Error('Alloc failed: not enough bytes.');
      }
      return index;
    }
  }

  free(address: MemoryAddress): void {
    // noop
  }
}
