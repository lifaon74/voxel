export interface Texture2DToImageDataTrait {
  toImageData(): ImageData;
}
