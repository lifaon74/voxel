import { u32 } from '@lifaon/math';

export interface Texture2DSizeTrait {
  readonly x: u32;
  readonly y: u32;
}
