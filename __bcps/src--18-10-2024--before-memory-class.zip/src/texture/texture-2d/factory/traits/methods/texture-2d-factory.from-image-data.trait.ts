export interface Texture2DFactoryFromImageDataTrait<GNew> {
  fromImageData(imageData: ImageData): GNew;
}
