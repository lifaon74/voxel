export interface Texture2DFactoryFromImageBitmapTrait<GNew> {
  fromImageBitmap(imageBitmap: ImageBitmap): GNew;
}
