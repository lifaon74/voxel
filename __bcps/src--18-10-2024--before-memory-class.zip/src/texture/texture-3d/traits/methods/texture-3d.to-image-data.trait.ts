export interface Texture3DToImageDataTrait {
  toImageData(): ImageData;
}
