import { AllocFunction, create_bytes_buffer, create_simple_alloc_function } from '@lifaon/math';
import { MainVoxChunk } from '../chunks/main/main-vox-chunk';
import { write_vox_file_content } from './write_vox_file_content';

export function encode_vox_file_as_bytes(
  chunk: MainVoxChunk,
  output: Uint8Array = create_bytes_buffer(2 ** 24),
): Uint8Array {
  const alloc: AllocFunction = create_simple_alloc_function(output);
  write_vox_file_content(output, alloc, chunk);
  return output.subarray(0, alloc(0));
}
