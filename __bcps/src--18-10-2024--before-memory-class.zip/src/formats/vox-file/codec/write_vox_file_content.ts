import { alloc_u32, AllocFunction, BytesBuffer, write_u32_be } from '@lifaon/math';
import { MainVoxChunk } from '../chunks/main/main-vox-chunk';

import { write_unknown_vox_chunk } from '../chunks/unknown/write_unknown_vox_chunk';

export function write_vox_file_content(
  buffer: BytesBuffer,
  alloc: AllocFunction,
  chunk: MainVoxChunk,
): void {
  buffer[alloc(1)] = 0x56 /* V */;
  buffer[alloc(1)] = 0x4f /* O */;
  buffer[alloc(1)] = 0x58 /* X */;
  buffer[alloc(1)] = 0x20 /* SPACE */;

  write_u32_be(buffer, alloc_u32(alloc), 150);

  write_unknown_vox_chunk(buffer, alloc, chunk);
}
