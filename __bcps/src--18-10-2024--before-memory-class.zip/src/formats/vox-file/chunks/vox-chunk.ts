export interface VoxChunk<GType extends string> {
  readonly type: GType;
}
